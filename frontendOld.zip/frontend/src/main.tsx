import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App"; // Import the root component
import "./index.css"; // Import Tailwind CSS or other global styles

// Create a root for ReactDOM
ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
